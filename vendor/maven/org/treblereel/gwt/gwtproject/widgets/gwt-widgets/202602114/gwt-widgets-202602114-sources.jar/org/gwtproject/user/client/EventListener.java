/*
 * Copyright 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.gwtproject.user.client;

/**
 * Receives low-level browser events. The implementer registers for DOM events using {@link
 * DOM#setEventListener(Element, EventListener)}.
 *
 * <p>Only subclasses of {@link org.gwtproject.user.client.ui.Widget} should attempt to listen to
 * browser events.
 */
public interface EventListener {

  /**
   * Fired whenever a browser event is received.
   *
   * @param event the event received
   */
  void onBrowserEvent(Event event);
}
